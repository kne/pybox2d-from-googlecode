"""Phil's pyGame Utilities


"""
__version__ = '0.10.6'

# vim: set filetype=python sts=4 sw=4 noet si :
